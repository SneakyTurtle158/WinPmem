#include "winpmem.h"
#include "pte_mmap.h"

void pte_mmap_windows_delete(PTE_MMAP_OBJ *self);
PTE_MMAP_OBJ *pte_mmap_windows_new(void);
